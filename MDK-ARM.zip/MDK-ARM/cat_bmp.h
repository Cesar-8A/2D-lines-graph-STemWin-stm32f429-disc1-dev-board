#include <stdlib.h>

#include "GUI.h"

#ifndef GUI_CONST_STORAGE
  #define GUI_CONST_STORAGE const
#endif

extern GUI_CONST_STORAGE GUI_BITMAP bmcat_1_bmp;

extern GUI_CONST_STORAGE GUI_BITMAP bmcat_2_bmp;

extern GUI_CONST_STORAGE GUI_BITMAP bmcat_3_bmp;